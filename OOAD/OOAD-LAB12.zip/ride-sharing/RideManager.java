import java.util.HashMap;
import java.util.Map;

public class RideManager {
    private static RideManager instance;
    private Map<String, Vehicle> activeRides;
    private VehicleFactory vehicleFactory;
    private int rideCounter;

    private RideManager() {
        activeRides = new HashMap<>();
        vehicleFactory = new VehicleFactory();
        rideCounter = 0;
    }

    public static synchronized RideManager getInstance() {
        if (instance == null) {
            instance = new RideManager();
        }
        return instance;
    }

    public String allocateRide(String vehicleType) {
        Vehicle vehicle = vehicleFactory.createVehicle(vehicleType);
        String rideId = "RIDE-" + (++rideCounter);
        activeRides.put(rideId, vehicle);
        return rideId;
    }

    public boolean completeRide(String rideId) {
        if (activeRides.containsKey(rideId)) {
            activeRides.remove(rideId);
            return true;
        }
        return false;
    }

    public Vehicle getRideDetails(String rideId) {
        return activeRides.get(rideId);
    }

    public int getActiveRideCount() {
        return activeRides.size();
    }

    public void printActiveRides() {
        System.out.println("\n=== Active Rides ===");
        for (Map.Entry<String, Vehicle> entry : activeRides.entrySet()) {
            System.out.println("Ride ID: " + entry.getKey() + 
                             " | Type: " + entry.getValue().getType() +
                             " | Capacity: " + entry.getValue().getCapacity() +
                             " | Fare: $" + entry.getValue().getBaseFare());
        }
    }
}
