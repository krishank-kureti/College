public class Sedan implements Vehicle {
    @Override
    public String getType() {
        return "Sedan";
    }

    @Override
    public int getCapacity() {
        return 4;
    }

    @Override
    public double getBaseFare() {
        return 100.0;
    }
}
