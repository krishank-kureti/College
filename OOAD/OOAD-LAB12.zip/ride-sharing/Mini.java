public class Mini implements Vehicle {
    @Override
    public String getType() {
        return "Mini";
    }

    @Override
    public int getCapacity() {
        return 4;
    }

    @Override
    public double getBaseFare() {
        return 50.0;
    }
}
