public class RideSharingDemo {
    public static void main(String[] args) {
        System.out.println("=== Ride-Sharing Application Demo ===");
        System.out.println("Using Factory Pattern + Singleton RideManager\n");

        RideManager manager = RideManager.getInstance();
        
        String ride1 = manager.allocateRide("mini");
        String ride2 = manager.allocateRide("sedan");
        String ride3 = manager.allocateRide("suv");
        String ride4 = manager.allocateRide("mini");
        
        System.out.println("Allocated Rides:");
        System.out.println("Ride 1 (Mini): " + ride1);
        System.out.println("Ride 2 (Sedan): " + ride2);
        System.out.println("Ride 3 (SUV): " + ride3);
        System.out.println("Ride 4 (Mini): " + ride4);

        manager.printActiveRides();
        
        System.out.println("\n--- Ride Details ---");
        System.out.println(ride1 + ": " + manager.getRideDetails(ride1).getType() + 
                         ", Capacity: " + manager.getRideDetails(ride1).getCapacity());
        System.out.println(ride2 + ": " + manager.getRideDetails(ride2).getType() + 
                         ", Capacity: " + manager.getRideDetails(ride2).getCapacity());
        System.out.println(ride3 + ": " + manager.getRideDetails(ride3).getType() + 
                         ", Capacity: " + manager.getRideDetails(ride3).getCapacity());

        System.out.println("\n--- Completing Rides ---");
        manager.completeRide(ride2);
        System.out.println("Completed: " + ride2);
        
        manager.printActiveRides();
        
        System.out.println("\n--- Singleton Verification ---");
        RideManager manager2 = RideManager.getInstance();
        System.out.println("Same instance? " + (manager == manager2));
        System.out.println("Active rides in manager2: " + manager2.getActiveRideCount());
    }
}
