public interface Vehicle {
    String getType();
    int getCapacity();
    double getBaseFare();
}
