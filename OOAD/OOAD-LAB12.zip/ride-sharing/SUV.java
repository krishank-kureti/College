public class SUV implements Vehicle {
    @Override
    public String getType() {
        return "SUV";
    }

    @Override
    public int getCapacity() {
        return 6;
    }

    @Override
    public double getBaseFare() {
        return 150.0;
    }
}
