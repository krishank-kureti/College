public class VehicleFactory {
    
    public Vehicle createVehicle(String vehicleType) {
        if (vehicleType == null) {
            throw new IllegalArgumentException("Vehicle type cannot be null");
        }
        
        switch (vehicleType.toLowerCase()) {
            case "mini":
                return new Mini();
            case "sedan":
                return new Sedan();
            case "suv":
                return new SUV();
            default:
                throw new IllegalArgumentException("Unknown vehicle type: " + vehicleType);
        }
    }
}
