import java.util.HashMap;
import java.util.Map;

public class NutritionManager {
    private static NutritionManager instance;
    private Map<String, Integer> calories;
    private Map<String, String> dietaryInfo;

    private NutritionManager() {
        calories = new HashMap<>();
        dietaryInfo = new HashMap<>();
        initializeNutritionData();
    }

    public static synchronized NutritionManager getInstance() {
        if (instance == null) {
            instance = new NutritionManager();
        }
        return instance;
    }

    private void initializeNutritionData() {
        calories.put("veg_burger", 350);
        calories.put("chicken_burger", 450);
        calories.put("paneer_wrap", 380);
        calories.put("chicken_wrap", 420);
        
        calories.put("cheese", 120);
        calories.put("lettuce", 10);
        calories.put("tomato", 15);
        calories.put("onions", 20);
        
        calories.put("fries", 230);
        calories.put("onion_rings", 180);
        calories.put("salad", 80);
        
        calories.put("cola", 140);
        calories.put("lemonade", 60);
        calories.put("water", 0);
        calories.put("juice", 100);

        dietaryInfo.put("veg_burger", "Vegetarian");
        dietaryInfo.put("chicken_burger", "Non-Vegetarian");
        dietaryInfo.put("paneer_wrap", "Vegetarian");
        dietaryInfo.put("chicken_wrap", "Non-Vegetarian");
        
        dietaryInfo.put("cheese", "Vegetarian");
        dietaryInfo.put("lettuce", "Vegan");
        dietaryInfo.put("tomato", "Vegan");
        dietaryInfo.put("onions", "Vegan");
        
        dietaryInfo.put("fries", "Vegan");
        dietaryInfo.put("onion_rings", "Vegan");
        dietaryInfo.put("salad", "Vegan");
        
        dietaryInfo.put("cola", "Vegan");
        dietaryInfo.put("lemonade", "Vegan");
        dietaryInfo.put("water", "Vegan");
        dietaryInfo.put("juice", "Vegan");
    }

    public int getCalories(String item) {
        return calories.getOrDefault(item, 0);
    }

    public String getDietaryInfo(String item) {
        return dietaryInfo.getOrDefault(item, "Unknown");
    }

    public int calculateTotalCalories(Meal meal) {
        int total = 0;
        total += getCalories(meal.getBaseItem());
        for (String topping : meal.getToppings()) {
            total += getCalories(topping);
        }
        for (String side : meal.getSides()) {
            total += getCalories(side);
        }
        for (String beverage : meal.getBeverages()) {
            total += getCalories(beverage);
        }
        return total;
    }

    public String getMealDietaryType(Meal meal) {
        if (meal.getBaseItem() != null && 
            dietaryInfo.get(meal.getBaseItem()).equals("Non-Vegetarian")) {
            return "Non-Vegetarian";
        }
        return "Vegetarian";
    }
}
