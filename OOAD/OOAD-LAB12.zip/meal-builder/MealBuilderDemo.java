public class MealBuilderDemo {
    public static void main(String[] args) {
        System.out.println("=== Meal Builder Application Demo ===");
        System.out.println("Using Builder Pattern + Singleton NutritionManager\n");

        NutritionManager nutritionManager = NutritionManager.getInstance();
        System.out.println("Singleton Nutrition Manager initialized\n");

        MealDirector director = new MealDirector();

        System.out.println("--- Building Veg Meal ---");
        MealBuilder vegBuilder = new VegMealBuilder();
        director.setMealBuilder(vegBuilder);
        Meal vegMeal = director.construct();
        System.out.println(vegMeal);
        
        int vegCalories = nutritionManager.calculateTotalCalories(vegMeal);
        String vegDietType = nutritionManager.getMealDietaryType(vegMeal);
        System.out.println("Total Calories: " + vegCalories);
        System.out.println("Dietary Type: " + vegDietType);

        System.out.println("\n--- Building Non-Veg Meal ---");
        MealBuilder nonVegBuilder = new NonVegMealBuilder();
        director.setMealBuilder(nonVegBuilder);
        Meal nonVegMeal = director.construct();
        System.out.println(nonVegMeal);
        
        int nonVegCalories = nutritionManager.calculateTotalCalories(nonVegMeal);
        String nonVegDietType = nutritionManager.getMealDietaryType(nonVegMeal);
        System.out.println("Total Calories: " + nonVegCalories);
        System.out.println("Dietary Type: " + nonVegDietType);

        System.out.println("\n--- Building Basic Meal (Veg) ---");
        MealBuilder basicVegBuilder = new VegMealBuilder();
        director.setMealBuilder(basicVegBuilder);
        Meal basicMeal = director.constructBasic();
        System.out.println(basicMeal);
        System.out.println("Total Calories: " + nutritionManager.calculateTotalCalories(basicMeal));

        System.out.println("\n--- Singleton Verification ---");
        NutritionManager nutritionManager2 = NutritionManager.getInstance();
        System.out.println("Same instance? " + (nutritionManager == nutritionManager2));
        
        System.out.println("\n--- Nutrition Data Consistency ---");
        System.out.println("Veg burger calories (from manager1): " + nutritionManager.getCalories("veg_burger"));
        System.out.println("Veg burger calories (from manager2): " + nutritionManager2.getCalories("veg_burger"));
    }
}
