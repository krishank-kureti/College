import java.util.ArrayList;
import java.util.List;

public class Meal {
    private String name;
    private String baseItem;
    private List<String> toppings = new ArrayList<>();
    private List<String> sides = new ArrayList<>();
    private List<String> beverages = new ArrayList<>();

    public void setName(String name) {
        this.name = name;
    }

    public void setBaseItem(String baseItem) {
        this.baseItem = baseItem;
    }

    public void addTopping(String topping) {
        toppings.add(topping);
    }

    public void addSide(String side) {
        sides.add(side);
    }

    public void addBeverage(String beverage) {
        beverages.add(beverage);
    }

    public String getName() {
        return name;
    }

    public String getBaseItem() {
        return baseItem;
    }

    public List<String> getToppings() {
        return toppings;
    }

    public List<String> getSides() {
        return sides;
    }

    public List<String> getBeverages() {
        return beverages;
    }

    @Override
    public String toString() {
        return "Meal{" +
                "name='" + name + '\'' +
                ", baseItem='" + baseItem + '\'' +
                ", toppings=" + toppings +
                ", sides=" + sides +
                ", beverages=" + beverages +
                '}';
    }
}
