public class VegMealBuilder extends MealBuilder {
    @Override
    public void buildBaseItem() {
        meal.setName("Veg Meal");
        meal.setBaseItem("veg_burger");
    }

    @Override
    public void buildToppings() {
        meal.addTopping("cheese");
        meal.addTopping("lettuce");
        meal.addTopping("tomato");
    }

    @Override
    public void buildSides() {
        meal.addSide("fries");
        meal.addSide("salad");
    }

    @Override
    public void buildBeverages() {
        meal.addBeverage("lemonade");
    }
}
