public class MealDirector {
    private MealBuilder mealBuilder;

    public void setMealBuilder(MealBuilder mealBuilder) {
        this.mealBuilder = mealBuilder;
    }

    public Meal construct() {
        mealBuilder.createNewMeal();
        mealBuilder.buildBaseItem();
        mealBuilder.buildToppings();
        mealBuilder.buildSides();
        mealBuilder.buildBeverages();
        return mealBuilder.getMeal();
    }

    public Meal constructBasic() {
        mealBuilder.createNewMeal();
        mealBuilder.buildBaseItem();
        mealBuilder.buildBeverages();
        return mealBuilder.getMeal();
    }

    public Meal constructWithSides() {
        mealBuilder.createNewMeal();
        mealBuilder.buildBaseItem();
        mealBuilder.buildSides();
        mealBuilder.buildBeverages();
        return mealBuilder.getMeal();
    }
}
