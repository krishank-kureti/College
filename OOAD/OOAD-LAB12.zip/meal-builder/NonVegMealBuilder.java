public class NonVegMealBuilder extends MealBuilder {
    @Override
    public void buildBaseItem() {
        meal.setName("Non-Veg Meal");
        meal.setBaseItem("chicken_burger");
    }

    @Override
    public void buildToppings() {
        meal.addTopping("cheese");
        meal.addTopping("tomato");
        meal.addTopping("onions");
    }

    @Override
    public void buildSides() {
        meal.addSide("fries");
        meal.addSide("onion_rings");
    }

    @Override
    public void buildBeverages() {
        meal.addBeverage("cola");
    }
}
