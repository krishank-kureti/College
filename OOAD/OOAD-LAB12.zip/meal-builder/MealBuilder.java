public abstract class MealBuilder {
    protected Meal meal;
    protected NutritionManager nutritionManager;

    public MealBuilder() {
        this.nutritionManager = NutritionManager.getInstance();
    }

    public void createNewMeal() {
        meal = new Meal();
    }

    public Meal getMeal() {
        return meal;
    }

    public abstract void buildBaseItem();
    public abstract void buildToppings();
    public abstract void buildSides();
    public abstract void buildBeverages();
}
