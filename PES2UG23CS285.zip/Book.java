class Book {
    String title;
    String author;
    boolean isAvailable;

    Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    boolean isAvailable() {
        return isAvailable;
    }

    void setAvailable(boolean status) {
        isAvailable = status;
    }

    public String toString() {
        return title + " by " + author;
    }
}