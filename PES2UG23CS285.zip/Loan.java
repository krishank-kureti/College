class Loan {
    User user;
    Book book;

    Loan(User user, Book book) {
        this.user = user;
        this.book = book;
    }
}