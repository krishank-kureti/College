public class Main {
    public static void main(String[] args) {
        LibraryController controller = new LibraryController();

        controller.addBook("Java Basics", "Author A");
        controller.addBook("OOP Concepts", "Author B");

        User s1 = new StudentUser("Alice");
        User f1 = new FacultyUser("Dr. Bob");

        controller.registerUser(s1);
        controller.registerUser(f1);

        Book book = controller.library.books.get(0);

        controller.borrowBook(s1, book);
        controller.displayUserDetails(s1);

        controller.returnBook(s1, book);
        controller.displayAvailableBooks();
    }
}