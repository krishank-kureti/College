class StudentUser extends User {
    StudentUser(String name) {
        super(name);
    }

    int getMaxBooks() {
        return 3;
    }
}