class LibraryController {
    Library library = new Library();

    void addBook(String title, String author) {
        library.addBook(new Book(title, author));
    }

    void registerUser(User user) {
        library.addUser(user);
    }

    void borrowBook(User user, Book book) {
        if (book.isAvailable() && user.borrowBook(book)) {
            book.setAvailable(false);
            new Loan(user, book);
            System.out.println("Book borrowed successfully");
        } else {
            System.out.println("Cannot borrow book");
        }
    }

    void returnBook(User user, Book book) {
        user.returnBook(book);
        book.setAvailable(true);
        System.out.println("Book returned successfully");
    }

    void displayAvailableBooks() {
        for (Book b : library.getAvailableBooks()) {
            System.out.println(b);
        }
    }

    void displayUserDetails(User user) {
        System.out.println("User: " + user.name);
        System.out.println("Borrowed Books:");
        for (Book b : user.borrowedBooks) {
            System.out.println(b);
        }
    }
}