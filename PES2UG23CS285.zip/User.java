import java.util.*;

abstract class User {
    String name;
    List<Book> borrowedBooks;

    User(String name) {
        this.name = name;
        borrowedBooks = new ArrayList<>();
    }

    abstract int getMaxBooks();

    boolean borrowBook(Book book) {
        if (borrowedBooks.size() < getMaxBooks()) {
            borrowedBooks.add(book);
            return true;
        }
        return false;
    }

    void returnBook(Book book) {
        borrowedBooks.remove(book);
    }
}