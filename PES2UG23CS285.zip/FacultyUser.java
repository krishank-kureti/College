class FacultyUser extends User {
    FacultyUser(String name) {
        super(name);
    }

    int getMaxBooks() {
        return 5;
    }
}